package contactApp;

import java.util.Vector;
import java.util.Random;

public class ContactService {


    private Vector<Contact> myContacts = new Vector<Contact>();

    private int numContacts = 0;

    public int getNumContacts() {
        return numContacts;
    }

    public Vector<Contact> getContactLIst(){
        return myContacts;
    }

    public void addContact(String contactID, String fName, String lName, String phoneNumber, String contactAddress) {

        Contact newContact = new Contact(contactID, fName, lName, phoneNumber, contactAddress);

        myContacts.add(newContact);

        numContacts++;
    }

    public void addContact(Contact contact) {

        myContacts.add(contact);

        numContacts++;
    }

    public void removeContact(String contactID) {

        if (contactID == null || contactID.length() > 10) {
            throw new IllegalArgumentException("Invalid contact ID");
        }

        if (myContacts.isEmpty()) {
            throw new IllegalArgumentException("There are no contacts saved.");
        }

        int index = -1;
        for (Contact c: myContacts) {
            if (c.getContactID() == contactID) {
                index = myContacts.indexOf(c);
            }
        }

        if (index == -1) {
            System.out.println("Not found.");
            return;
        }

        else {
            myContacts.remove(index);
            numContacts--;
            System.out.println("Removed.");
        }
    }

    public void removeContact(Contact contact) {
        myContacts.remove(contact);
        numContacts --;
    }

    void updateContact(String ID, String update, int selection) {
        if (ID == null || ID.length() > 10 || update == null || selection < 0) {
            throw new IllegalArgumentException("Invalid Contact ID");
        }

        if (myContacts.isEmpty()) {
            throw new IllegalArgumentException("There are no contacts to update.");
        }

        int index = -1;

        for (Contact c: myContacts) {
            if (c.getContactID() == ID) {
                index = myContacts.indexOf(c);
            }
        }

        if (index == -1) {
            System.out.println("Not found");
            return;
        }

        Contact updatedContact = myContacts.get(index);

        switch(selection) {
            case 1:{
                updatedContact.setFirstName(update);
                break;
            }

            case 2:{
                updatedContact.setLastName(update);
                break;
            }

            case 3:{
                updatedContact.setPhoneNumber(update);
                break;
            }

            case 4:{
                updatedContact.setContactAddress(update);
                break;
            }

            default:{
                removeContact(myContacts.elementAt(index));
                addContact(updatedContact);
            }
        }

    }

    public void updatedContact(String ID, String fName, String lName, String pNumber, String contactAddress) {
        if (ID == null || ID.length() > 10) {
            throw new IllegalArgumentException("Invalid contact ID.");
        }

        if (myContacts.isEmpty()) {
            throw new IllegalArgumentException("There are no contacts.");
        }

        int index = -1;

        for (Contact c: myContacts) {
            if (c.getContactID() == ID) {
                index = myContacts.indexOf(c);
            }
        }

        if (index == -1) {
            System.out.println("Not found");
            return;
        }

        Contact tempContact = myContacts.get(index);

        tempContact.setFirstName(fName);
        tempContact.setFirstName(lName);
        tempContact.setFirstName(pNumber);
        tempContact.setFirstName(contactAddress);

        myContacts.remove(index);
        myContacts.add(tempContact);
    }

    public String generateUniqueId() {
        Random rand = new Random();
        int newID = rand.nextInt(1000000000);
        String uniqueID = Integer.toString(newID);

        for (Contact c: myContacts) {
            while(c.getContactID() == uniqueID) {
                newID = rand.nextInt(1000000000);
                uniqueID = Integer.toString(newID);
            }
        }

        System.out.println("New Contact ID created: " + uniqueID);
        return uniqueID;
    }
}