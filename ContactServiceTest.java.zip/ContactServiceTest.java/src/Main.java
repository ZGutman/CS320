package contactApp;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactServiceTest {


    @Test
    void testAddContactMethod() {
        ContactService contactService = new ContactService();
        String testID = contactService.generateUniqueId();
        Contact contact = new Contact(testID, "Zach", "Ray", "2171042025", "1000 Elm Street");

        contactService.addContact(contact);

        assertTrue(!contactService.getContactLIst().isEmpty());
        assertTrue(contactService
                .getContactLIst()
                .elementAt(0)
                .getContactID()
                .equals(testID));
        assertTrue(contactService.getNumContacts() > 0);
    }

    @Test
    void testRemoveContactMethod() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("123456", "Zach", "Ray", "2171042025", "1000 Elm Street");

        Assertions.assertThrows(IllegalArgumentException.class, () ->{
            contactService.removeContact("");
        });

        Assertions.assertThrows(IllegalArgumentException.class, () ->{
            contactService.removeContact("12345678901");
        });

        Assertions.assertThrows(IllegalArgumentException.class, () ->{
            contactService.removeContact("1234567890");
        });

        contactService.addContact(contact);

        contactService.removeContact("123457");

        // contact list is not empty, count is not zero
        // contact not removed because contact doesn't exist
        assertTrue(!contactService.getContactLIst().isEmpty());
        assertTrue(contactService.getNumContacts() != 0);

        contactService.removeContact("123456");

        // list is empty, count is zero, contact successfully removed
        assertTrue(contactService.getNumContacts() == 0);
        assertTrue(contactService.getContactLIst().isEmpty());

    }

    @Test
    void testUpdateContactMethodErrors() {
        ContactService contactService = new ContactService();
        Assertions.assertThrows(IllegalArgumentException.class, () ->{
            contactService.updateContact("123456", "Lawrence", 1);
        });

        Contact contact = new Contact("123456", "Zach", "Ray", "2171042025", "1000 Elm Street");
        contactService.addContact(contact);
        assertTrue(!contactService.getContactLIst().isEmpty());

        Assertions.assertThrows(IllegalArgumentException.class, () ->{
            contactService.updateContact("12345678901", "Zach", 1);
        });
        Assertions.assertThrows(IllegalArgumentException.class, () ->{
            contactService.updateContact(null, "Zach", 1);
        });
        Assertions.assertThrows(IllegalArgumentException.class, () ->{
            contactService.updateContact("123456", null, 1);
        });
        Assertions.assertThrows(IllegalArgumentException.class, () ->{
            contactService.updateContact("123456", "Zach", -1);
        });

        contactService.updateContact("123457", "Zach", 1);

        contactService.updateContact("123456", "Zach", 5);

    }

    @Test
    void testUpdateContactMethod() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("123456", "Zach", "Ray", "2171042025", "1000 Elm Street");
        contactService.addContact(contact);
        assertTrue(!contactService.getContactLIst().isEmpty());

        contactService.updateContact("123456", "Lawrence", 1);
        assertTrue(contactService
                .getContactLIst()
                .elementAt(0)
                .getName()
                .equals("Lawrence Zach"));
        contactService.updateContact("123456", "Johnson", 2);
        assertTrue(contactService
                .getContactLIst()
                .elementAt(0)
                .getName()
                .equals("Lawrence Johnson"));
        contactService.updateContact("123456", "4402255499", 3);
        assertTrue(contactService
                .getContactLIst()
                .elementAt(0)
                .getPhoneNumber()
                .equals("4402255499"));
        contactService.updateContact("123456", "4910 Carson Ave", 4);
        assertTrue(contactService
                .getContactLIst()
                .elementAt(0)
                .getContactAddress()
                .equals("4910 Carson Ave"));

        Assertions.assertThrows(IllegalArgumentException.class, () ->{
            contactService.updateContact("123456", "LawrenceJoseph", 1);
        });

        assertTrue(contactService.getNumContacts() == 1);
        assertTrue(contactService.getContactLIst().elementAt(0)
                .getName().equals("Lawrence Johnson"));

    }

}