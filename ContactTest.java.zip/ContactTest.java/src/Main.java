package contactApp;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


public class ContactTest {

    @Test
    void testContactNullArguments() {
        Assertions.assertThrows(IllegalArgumentException.class, () ->{
            new Contact(null, null, null, null, null);
        });
    }

    @Test
    void testContactAndGetters() {
        Contact contact = new Contact("123456", "Zach", "Gutman", "6767676767", "1000 Elm St.");
        assertTrue(contact.getName().equals("Matt Gutman"));
        assertTrue(contact.getPhoneNumber().equals("6767676767"));
        assertTrue(contact.getContactAddress().equals("1000 Elm St."));
        assertTrue(contact.getContactID().equals("123456"));
    }

    @Test
    void testSetFirstAndLastName() {
        Contact contact = new Contact("123456", "Zach", "Gutman", "6767676767", "1000 Elm St.");
        contact.setFirstName("Zach");
        contact.setLastName("Gutman");
        assertTrue(contact.getName().equals("Zach Gutman"));
    }

    @Test
    void testSetPhoneNumberAndAddress() {
        Contact contact = new Contact("123456", "Zach", "Gutman", "6767676767", "1000 Elm St.");
        contact.setPhoneNumber("6767676767");
        contact.setContactAddress("1000 Elm St.");
        assertTrue(contact.getPhoneNumber().equals("6767676767"));
        assertTrue(contact.getContactAddress().equals("1000 Elm St."));
    }

    @Test
    void testNullSetAttributes() {
        Contact contact = new Contact("123456", "Zach", "Gutman", "6767676767", "1000 Elm St.");
        Assertions.assertThrows(IllegalArgumentException.class, () ->{
            contact.setFirstName(null);
        });
        Assertions.assertThrows(IllegalArgumentException.class, () ->{
            contact.setLastName(null);
        });
        Assertions.assertThrows(IllegalArgumentException.class, () ->{
            contact.setContactAddress(null);
        });
        Assertions.assertThrows(IllegalArgumentException.class, () ->{
            contact.setPhoneNumber(null);
        });
    }

    @Test
    void testAllGetters() {
        Contact contact = new Contact("123456", "Zach", "Gutman", "6767676767", "1000 Elm St.");
        assertTrue(contact.getName().equals("Zach Gutman"));
        assertTrue(contact.getContactID().equals("123456"));
        assertTrue(contact.getPhoneNumber().equals("6767676767"));
        assertTrue(contact.getContactAddress().equals("1000 Elm St."));
    }

}